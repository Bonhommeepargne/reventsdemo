## Features

This is a snippets file for use with the React Redux Firestore training course.  Please only install if taking this course.

## Requirements

Please be a student on the course for details of using this extension.

## Known Issues

The course is not yet published...

## Release Notes

Not released yet.